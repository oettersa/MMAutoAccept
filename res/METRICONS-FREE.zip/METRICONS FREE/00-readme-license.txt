METRICONS FREE
Icons for Windows 8 
Created by Stoian Oliviu
WWW: http://iconswindows.com/
Twitter: @oliviustoian

----------

LICENSE:
You're free to use these icons only for non-commercial purposes.

ATTRIBUTION:
None required for use by you, your company, your clients. 
But if you'd like to spread the word by linking to iconswindows.com from your 
website, blogpost, Twitter or wherever, your kind words are much appreciated.

QUESTIONS, COMMENTS:
Contact me via iconswindows.com or olivetty@gmail.com

Ownership and Usage
All ownership and copyright of the licensed icons remain the property of 
iconwindows.com and Oliviu Stoian.

Disclaimer
All licensed icons are provided 'as-is' without warranty of any kind, 
either expressed or implied.
    
Restrictions
Use for commercial purposes, embed the icons in a font, and insert them in your website using @font-face is restricted. 
The Icons may not be resold, sublicensed, rented, transferred or otherwise 
made available for use or detached from a product, software application or web 
page without express written permission from IconsWindows.
----------
You can download all 750 with the code ICNDEP25$OFF with $25 discount
----------
